-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for columbiairan
CREATE DATABASE IF NOT EXISTS `columbiairan` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `columbiairan`;

-- Dumping structure for table columbiairan.blogs
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_alt` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.blogs: ~0 rows (approximately)

-- Dumping structure for table columbiairan.cache
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.cache: ~0 rows (approximately)

-- Dumping structure for table columbiairan.cache_locks
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.cache_locks: ~0 rows (approximately)

-- Dumping structure for table columbiairan.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_alt` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.categories: ~0 rows (approximately)
INSERT INTO `categories` (`id`, `name`, `photo`, `slug`, `meta_description`, `photo_alt`, `page_title`, `created_at`, `updated_at`) VALUES
	(1, 'یخچال', 'freezer.jpg', 'freezer', 'freezer', 'freezer', 'freezer', '2026-02-09 20:27:50', '2026-02-09 20:27:50'),
	(2, 'ماکروفر', 'microvave.jpg', 'microvave', 'microvave', 'microvave', 'microvave', '2026-02-11 10:08:55', '2026-02-11 10:08:55'),
	(3, 'لباسشویی', 'lebas.jpg', 'lebas', 'lebas', 'lebas', 'lebas', '2026-02-11 17:23:02', '2026-02-11 17:23:02');

-- Dumping structure for table columbiairan.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table columbiairan.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.jobs: ~0 rows (approximately)

-- Dumping structure for table columbiairan.job_batches
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.job_batches: ~0 rows (approximately)

-- Dumping structure for table columbiairan.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.migrations: ~0 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '0001_01_01_000000_create_users_table', 1),
	(2, '0001_01_01_000001_create_cache_table', 1),
	(3, '0001_01_01_000002_create_jobs_table', 1),
	(4, '2025_12_12_083632_create_sessions_table', 1),
	(5, '2025_12_12_145040_create_categories_table', 1),
	(6, '2025_12_12_145909_create_products_table', 1),
	(7, '2025_12_12_152456_create_product_photos_table', 1),
	(8, '2025_12_12_153353_create_product_sizes_table', 1),
	(9, '2025_12_12_155645_create_product_colors_table', 1),
	(10, '2025_12_12_161106_create_product_comments_table', 1),
	(11, '2025_12_13_195135_create_product_variants_table', 1),
	(12, '2025_12_15_183504_create_blogs_table', 1),
	(13, '2025_12_15_184551_create_photo_banners_table', 1),
	(14, '2025_12_15_185125_create_video_banners_table', 1);

-- Dumping structure for table columbiairan.offers
CREATE TABLE IF NOT EXISTS `offers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `discount_amount` decimal(15,0) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table columbiairan.offers: ~0 rows (approximately)

-- Dumping structure for table columbiairan.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint DEFAULT NULL,
  `send_method_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_amount` decimal(15,0) NOT NULL,
  `pay_amount` decimal(15,0) NOT NULL,
  `track_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `id_get` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trans_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `send_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `postal_track` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `send_method_id` (`send_method_id`),
  KEY `offer_id_forigen` (`offer_id`),
  CONSTRAINT `offer_id_forigen` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `send_method_id_foreign` FOREIGN KEY (`send_method_id`) REFERENCES `send_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.orders: ~0 rows (approximately)

-- Dumping structure for table columbiairan.order_items
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `product_color_id` bigint unsigned NOT NULL,
  `product_size_id` bigint unsigned NOT NULL,
  `price` decimal(15,0) NOT NULL,
  `discount` decimal(15,0) DEFAULT NULL,
  `quantity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_product_color_id_foreign` (`product_color_id`),
  KEY `order_items_product_size_id_foreign` (`product_size_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `order_items_product_color_id_foreign` FOREIGN KEY (`product_color_id`) REFERENCES `product_colors` (`id`),
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `order_items_product_size_id_foreign` FOREIGN KEY (`product_size_id`) REFERENCES `product_sizes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.order_items: ~0 rows (approximately)

-- Dumping structure for table columbiairan.order_offers
CREATE TABLE IF NOT EXISTS `order_offers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `offer_id` bigint unsigned NOT NULL,
  `discount_applied` decimal(15,0) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_order_offer` (`order_id`,`offer_id`),
  KEY `fk_offer` (`offer_id`),
  CONSTRAINT `fk_offer` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table columbiairan.order_offers: ~0 rows (approximately)

-- Dumping structure for table columbiairan.photo_banners
CREATE TABLE IF NOT EXISTS `photo_banners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_alt` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.photo_banners: ~4 rows (approximately)
INSERT INTO `photo_banners` (`id`, `title`, `description`, `photo`, `photo_alt`, `link`, `created_at`, `updated_at`) VALUES
	(1, 'هر آنچه برای خانه‌ات نیاز داری', 'از آشپزخانه تا اتاق خواب، با بهترین قیمت و پشتیبانی واقعی کنار تو هستیم', 'banner1770824762.png', 'فروشگاه لوازم خانگی افشار کالا', NULL, '2026-02-09 20:18:39', '2026-02-11 15:46:02'),
	(2, 'سرخ کن', 'بهترین برندها با ضمانت اصالت، قیمت رقابتی و ارسال سریع به سراسر کشور', 'banner1770824707.png', 'فروشگاه لوازم خانگی افشار کالا', NULL, '2026-02-09 20:19:23', '2026-02-11 15:46:42'),
	(3, 'تلویزیون', 'بهترین برندها با ضمانت اصالت، قیمت رقابتی و ارسال سریع به سراسر کشور', 'banner1770824700.png', 'فروشگاه لوازم خانگی افشار کالا', NULL, '2026-02-09 20:19:59', '2026-02-11 15:46:52'),
	(4, 'لیاسشویی', 'بهترین برندها با ضمانت اصالت، قیمت رقابتی و ارسال سریع به سراسر کشور', 'banner1770824743.png', 'فروشگاه لوازم خانگی افشار کالا', NULL, '2026-02-09 20:20:28', '2026-02-11 15:47:09'),
	(5, 'کیفیتی که می‌ماند', 'لوازم خانگی اصل، قیمت مناسب، تحویل سریع', 'banner1770823346.png', 'فروشگاه لوازم خانگی افشار کالا', NULL, '2026-02-09 20:21:01', '2026-02-11 15:23:24');

-- Dumping structure for table columbiairan.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_special` tinyint(1) NOT NULL DEFAULT '0',
  `price` decimal(15,0) NOT NULL,
  `discount` decimal(15,0) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `material` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dimension` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_category_id_foreign` (`category_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.products: ~0 rows (approximately)
INSERT INTO `products` (`id`, `name`, `category_id`, `slug`, `is_special`, `price`, `discount`, `description`, `material`, `weight`, `dimension`, `meta_description`, `page_title`, `created_at`, `updated_at`) VALUES
	(1, 'یخچال سامسونگ RS80 تستی', 1, 'sam-rs80', 1, 5000000, 0, '<p>یخچال سامسونگ RS80</p>', 'تیتان', '200 کیلوگرم', '2m*1m', 'sam-rs80', 'sam-rs80', '2026-02-09 20:30:46', '2026-02-12 11:34:02'),
	(2, 'ماکروفر کنوود تستی', 2, 'mic-cen', 1, 4000000, 500000, '<p>تست تست تست</p>', 'تیتان', '2 کیلوگرم', '20 * 10 سانتی متر', 'mic-cen', 'mic-cen', '2026-02-11 10:10:28', '2026-02-12 11:33:53');

-- Dumping structure for table columbiairan.product_colors
CREATE TABLE IF NOT EXISTS `product_colors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_colors_product_id_foreign` (`product_id`),
  CONSTRAINT `product_colors_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.product_colors: ~3 rows (approximately)
INSERT INTO `product_colors` (`id`, `product_id`, `name`, `code`, `created_at`, `updated_at`) VALUES
	(1, 1, 'سیاه', '#000000', '2026-02-09 20:31:34', '2026-02-09 20:31:34'),
	(2, 2, 'نقره ای', '#CACECB', '2026-02-11 10:13:05', '2026-02-11 10:13:05'),
	(3, 2, 'سیاه', '#000000', '2026-02-11 13:51:17', '2026-02-11 13:51:17'),
	(4, 2, 'قرمز', '#E43F3F', '2026-02-11 17:30:16', '2026-02-11 17:30:16');

-- Dumping structure for table columbiairan.product_comments
CREATE TABLE IF NOT EXISTS `product_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_response` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `product_comments_product_id_foreign` (`product_id`),
  CONSTRAINT `product_comments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.product_comments: ~0 rows (approximately)
INSERT INTO `product_comments` (`id`, `product_id`, `name`, `comment`, `admin_response`, `created_at`, `updated_at`, `status`) VALUES
	(3, 1, 'جواد', 'خوب بود', NULL, '2026-02-11 17:34:21', '2026-02-11 17:34:21', 2);

-- Dumping structure for table columbiairan.product_photos
CREATE TABLE IF NOT EXISTS `product_photos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_alt` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_photos_product_id_foreign` (`product_id`),
  CONSTRAINT `product_photos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.product_photos: ~4 rows (approximately)
INSERT INTO `product_photos` (`id`, `product_id`, `photo`, `photo_alt`, `created_at`, `updated_at`) VALUES
	(1, 1, 'sam-rs80-1.jpg', 'شش', '2026-02-09 20:31:03', '2026-02-09 20:31:03'),
	(2, 1, 'sam-rs80-2.jpg', 'شش', '2026-02-09 20:31:10', '2026-02-09 20:31:10'),
	(3, 2, 'mic-cen-1.png', 'ماکروفر', '2026-02-11 10:11:28', '2026-02-11 10:11:28'),
	(4, 2, 'mic-cen-2.jpg', 'ماکروفر', '2026-02-11 10:12:15', '2026-02-11 10:12:15');

-- Dumping structure for table columbiairan.product_sizes
CREATE TABLE IF NOT EXISTS `product_sizes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_sizes_product_id_foreign` (`product_id`),
  CONSTRAINT `product_sizes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.product_sizes: ~0 rows (approximately)
INSERT INTO `product_sizes` (`id`, `product_id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 1, '40', '2026-02-09 20:31:25', '2026-02-09 20:31:25'),
	(2, 2, 'متوسط', '2026-02-11 10:13:28', '2026-02-11 10:13:28'),
	(3, 2, '32', '2026-02-11 17:31:37', '2026-02-11 17:31:37');

-- Dumping structure for table columbiairan.product_variants
CREATE TABLE IF NOT EXISTS `product_variants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `size_id` bigint unsigned NOT NULL,
  `color_id` bigint unsigned NOT NULL,
  `count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_variants_product_id_size_id_color_id_unique` (`product_id`,`size_id`,`color_id`),
  KEY `product_variants_size_id_foreign` (`size_id`),
  KEY `product_variants_color_id_foreign` (`color_id`),
  CONSTRAINT `product_variants_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `product_colors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_variants_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_variants_size_id_foreign` FOREIGN KEY (`size_id`) REFERENCES `product_sizes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.product_variants: ~0 rows (approximately)
INSERT INTO `product_variants` (`id`, `product_id`, `size_id`, `color_id`, `count`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, 1, 1, '2026-02-09 20:31:45', '2026-02-12 13:46:31'),
	(2, 2, 2, 2, 1, '2026-02-11 10:13:37', '2026-02-12 18:45:31'),
	(3, 2, 3, 4, 8, '2026-02-11 17:32:05', '2026-02-12 18:49:19');

-- Dumping structure for table columbiairan.send_methods
CREATE TABLE IF NOT EXISTS `send_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table columbiairan.send_methods: ~0 rows (approximately)
INSERT INTO `send_methods` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
	(1, 'ارسال با تیپاکس', 'سراسر کشور', '2026-02-09 20:43:53', '2026-02-09 20:43:53');

-- Dumping structure for table columbiairan.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.sessions: ~2 rows (approximately)
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`, `created_at`, `updated_at`) VALUES
	('se149zjE0Vpc3yuAlRuyElhHBqMmR0lD3iPYR2U3', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTXh4aE0yWlpycVFpb29vZVRmWkxjS1JwcEc0dzNUR2c4aXZNSUZiYiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fX0=', 1770923570, NULL, NULL);

-- Dumping structure for table columbiairan.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_mobile_unique` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.users: ~0 rows (approximately)
INSERT INTO `users` (`id`, `name`, `mobile`, `type`, `password`, `deleted_at`, `created_at`, `updated_at`) VALUES
	(1, 'javad', '09301957431', 2, '$2y$12$ckriTYsm7eazcYH5XzaRdeAjdSuXTCl22iwB9TIe8faVtE7W3BcuK', NULL, '2026-02-09 20:23:52', '2026-02-12 09:08:54'),
	(2, 'شروین افشار', '09362910221', 1, '$2y$12$K09iMRjSt1jFhvhWc3wtB.raGHhgDTWq3Uss8F7JkbLie3iLgA1WW', NULL, '2026-02-11 17:36:18', '2026-02-12 09:08:54');

-- Dumping structure for table columbiairan.video_banners
CREATE TABLE IF NOT EXISTS `video_banners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `btn_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_mp4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_webm` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_alt` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sort` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table columbiairan.video_banners: ~0 rows (approximately)
INSERT INTO `video_banners` (`id`, `title`, `description`, `btn_text`, `video_mp4`, `video_webm`, `photo`, `photo_alt`, `link`, `meta_description`, `page_title`, `created_at`, `updated_at`, `sort`) VALUES
	(1, 'خانه‌ات را هوشمندانه انتخاب کن', 'بهترین برندها با ضمانت اصالت، قیمت رقابتی و ارسال سریع به سراسر کشور', 'شروع خرید', 'hero.jpg', 'hero.jpg', 'hero_banner_1_1770899528.png', 'فروشگاه لوازم خانگی افشار کالا', NULL, 'فروشگاه لوازم خانگی افشار کالا در شهر ساری', 'افشار کالا', '2026-02-09 20:16:58', '2026-02-12 12:32:08', 1),
	(2, 'بنر دوم', 'تست', 'تست', NULL, NULL, 'banner2.jpg', 'فروشگاه لوازم خانگی افشار کالا', NULL, 'aa', 'aa', '2026-02-12 09:39:13', '2026-02-12 09:39:16', 2),
	(3, 'بنر سوم', 'تست', 'تست', NULL, NULL, 'banner3.jpg', 'فروشگاه لوازم خانگی افشار کالا', NULL, 'aa', 'aa', '2026-02-12 11:24:08', '2026-02-12 11:24:09', 3),
	(4, 'بنر چهارم', 'بنر چهارم', 'بنر چهارم', NULL, NULL, 'banner4.jpg', 'فروشگاه لوازم خانگی افشار کالا', NULL, 'بنر چهارم', 'بنر چهارم', '2026-02-12 11:31:31', '2026-02-12 11:31:32', 4);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
